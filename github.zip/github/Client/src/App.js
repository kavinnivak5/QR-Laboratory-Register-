// // App.js
import React from 'react';
import TimeEntryForm from './components/TimeEntryForm';

function App() {

  return (
    <div>
      <h1>K.RAMAKRISHNAN COLLEGE OF TECHNOLOGY</h1>
      <TimeEntryForm />
    </div>
  );
}

export default App;